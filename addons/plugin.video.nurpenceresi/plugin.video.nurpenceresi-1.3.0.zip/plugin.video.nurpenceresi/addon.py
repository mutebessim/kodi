﻿import sys,platform
import urlresolver
import urllib,urllib2,cookielib
import re,xbmcplugin,xbmcgui,xbmcaddon,xbmc
import json
import StringIO


xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
settings = xbmcaddon.Addon(id='plugin.video.nurpenceresi')

baseurl='http://www.nurpenceresi.com'

def KATEGORI():
      addDir("Son Eklenen Videolar",baseurl+"/?page=0",7,"")
      addDir("Şahıslara Göre Görüntülü Sohbetler",baseurl+"/sahislara-gore",1,"http://www.nurpenceresi.com/images/sahislara-gore.jpg")
      addDir("Konulara Göre Görüntülü Sohbetler",baseurl+"/konulara-gore",2,"http://www.nurpenceresi.com/images/konulara-gore.jpg")
      addDir("Risalelere Göre Görüntülü Sohbetler",baseurl+"/risale-i-nur-gore",3,"http://www.nurpenceresi.com/images/risalelelere-gore.jpg")
      addDir("Sohbetlerden Kısa Kısa",baseurl+"/kisa-kisa",4,"http://www.nurpenceresi.com/sites/all/themes/tema/images/rndersleri/menu-kisakisa.png")
      addDir("Müzakereli Risale-i Nur Dersleri",baseurl+"/muzakereli-risale-i-nur-dersleri",1,"http://www.nurpenceresi.com/sites/all/themes/tema/images/rndersleri/menu-muzakere.png")
      addDir("Hatıralar",baseurl+"/hatiralar",1,"http://www.nurpenceresi.com/sites/all/themes/tema/images/videolar/menu-hatiralar.png")
      addDir("Klipler",baseurl+"/klipler",4,"http://www.nurpenceresi.com/sites/all/themes/tema/images/videolar/menu-klipler.png")
      addDir("Sinevizyonlar",baseurl+"/sinevizyonlar",2,"http://www.nurpenceresi.com/sites/all/themes/tema/images/videolar/menu-sinevizyon.png")
      #addDir("Sempozyumlar","http://www.bediuzzamansaidnursi.org/videolar/sempozyum-paneller",1,"Daha Sonra Yazılacak")
      addDir("Bizden Videolar",baseurl+"/bizden-videolar",4,"http://www.nurpenceresi.com/sites/all/themes/tema/images/videolar/np-video-gri.png")
      addDir("Gençlerle Risale-i Nur Dersi",baseurl+"/genclerle-risale-i-nur-dersi",4,"http://www.nurpenceresi.com/sites/all/themes/tema/images/videolar/menu-genclerlerisalenur.png")
      addDir("Sesli Sohbetler",baseurl+"/sesliler/sesli-sohbetler",1,"")
def LISTELE1(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace("&lt;","<").replace("&gt;",">").replace("&amp;","&").replace("&#038;","&").replace("&#39;","'").replace("&#039;","'").replace("&#8211;","-").replace("&#8220;","-").replace("&#8221;","-").replace("&#8217;","'").replace("&quot;","\"")
        response.close()
        match=re.compile('<span class="field-content"><a href="(.+?)"><img src="(.+?)" alt="(.+?)".+?/></a></span>').findall(link)
        muzakere=re.compile('<span class="field-content"><a href="(.+?)">(.+?)</a></span>').findall(link)
        if match:
          for url,thumbnail,name in match:
            addDir(name,baseurl+url,4,thumbnail)
        else:
          for url,name in muzakere:
            addDir(name,baseurl+url,4,'http://www.nurpenceresi.com/sites/default/files/category_pictures/diger.jpg')
def LISTELE2(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace("&lt;","<").replace("&gt;",">").replace("&amp;","&").replace("&#038;","&").replace("&#39;","'").replace("&#039;","'").replace("&#8211;","-").replace("&#8220;","-").replace("&#8221;","-").replace("&#8217;","'").replace("&quot;","\"")
        response.close()
        match=re.compile('<span class="field-content"><a href="(.+?)"><img src="(.+?)" /><br>\n<h2>(.+?)</h2></a></span>').findall(link)
        konusuz=re.compile('<div class="views-field-field-kapakresim-fid">\n                <span class="field-content"><a href="(.+?)">.+?<img src="(.+?)".+?imagecache-videoresmi"/></a></a></span>\n  </div>\n  \n  <div class="views-field-title">\n                <span class="field-content"><a href=".+?">(.+?)</a></span>').findall(link)
        if match:
          for url,thumbnail,name in match:
            addDir(name,baseurl+url,4,"http://www.nurpenceresi.com/"+thumbnail)
        else:
          for url, thumnail, name in konusuz:
           addDir(name,baseurl+url,5,thumnail)
def LISTELE3(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace("&lt;","<").replace("&gt;",">").replace("&amp;","&").replace("&#038;","&").replace("&#39;","'").replace("&#039;","'").replace("&#8211;","-").replace("&#8220;","-").replace("&#8221;","-").replace("&#8217;","'").replace("&quot;","\"")
        response.close()
        match=re.compile('<span class="field-content"><a href="(.+?)"><img src="(.+?)" alt="(.+?)".+?/></a></span>').findall(link)
        for url,thumbnail,name in match:
          addDir(name,baseurl+url,2,thumbnail)
def BOLUMLER(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace("&lt;","<").replace("&gt;",">").replace("&amp;","&").replace("&#038;","&").replace("&#39;","'").replace("&#039;","'").replace("&#8211;","-").replace("&#8220;","-").replace("&#8221;","-").replace("&#8217;","'").replace("&quot;","\"")
        response.close()
        match=re.compile('<div class="views-field-field-kapakresim-fid">\n                <span class="field-content"><a href="(.+?)">.+?<img src="(.+?)".+?imagecache-videoresmi"/></a></a></span>\n  </div>\n  \n  <div class="views-field-title">\n                <span class="field-content"><a href=".+?">(.+?)</a></span>').findall(link)
        for url, thumnail, name in match:
                addDir(name,baseurl+url,5,thumnail)
        sayfa=re.compile('<li class="pager-next"><a href="(.+?)" title=".+?">.+?</a></li>').findall(link)
        for url in sayfa:
                addDir('..ileri [COLOR orange][B]>>>[/B][/COLOR]',baseurl+url,4,'special://home/addons/plugin.video.nurpenceresi/resources/images/next.png')
def VIDEOLINKS(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-sGB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<object type="application/x-shockwave-flash" .+? data="(.+?)&amp;amp;rel=0&amp;amp;enablejsapi=1&amp;amp;playerapiid=ytplayer&amp;amp;fs=1" id="media-youtube-default-external-object-1">').findall(link)
        match2=re.compile('<iframe src="(.+?)".+?"></iframe>').findall(link)
        match3=re.compile('<div class="field-item field-item-0"><a href="(.+?)" download >').findall(link)
        if match:
            for url in match:
                addDir(name+' youtube izle',url,6,'')
        if match2:
            for url in match2:
                addDir(name+' vimeo izle',url,6,'')
        elif match3:
            for url in match3:
                addDir(name+' wma dinle',url,6,'')
def SONVID(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent',
                       'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36')
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        match = re.compile(
                '<span class="field-content"><a href="(.+?)"><img src="(.+?)".+\n  </div>\n  \n  <div class="views-field-title">\n                <span class="field-content"><h2><a href=.+?">(.+?)</a></h2></span>').findall(
                link)
        for url,resim,name in match[:8]:
                addDir(name,baseurl+url,5,resim)
        listele = re.compile('<li class="pager-next last"><a href="(.+?)" class="active">').findall(link)
        if listele:
                for url in listele[:1]:
                        addDir("..ileri [COLOR orange][B]>>>[/B][/COLOR]",baseurl+url, 7, "special://home/addons/plugin.video.nurpenceresi/resources/images/next.png")

def oynat(url,name):
        playList.clear()
        url = str(url).encode('utf-8', 'ignore')


        if '.ts' in url:
                url= url
        elif 'rtmp:'  in url:
                url= url
        elif 'rtsp:'  in url:
                url= url
        elif  '.ts:' in url:
                url= url
        elif '.m3u8' in url:
                url= url
        elif '.wmv' in url:
                url= url
        elif '.mp4' in url:
                url= url
        elif '.wma' in url:
                url= url
        else:
                url=urlresolver.resolve(url)
        if url:
                addLink(name,url,'')

                listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                listitem.setInfo('video', {'name': name } )
                playList.add(str(url),listitem=listitem)
                xbmcPlayer.play(playList)
        else:
                showMessage("","[COLOR blue][B]Link bulunamadi ya da acilamiyor[/B][/COLOR]")







def get_url(url):
        req = urllib2.Request(url)
        req.add_header('Referer', url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36')
        #req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
        #req.add_header('Cache-Control', 'no-transform')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link







def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        KATEGORI()

elif mode==1:
        print ""+url
        LISTELE1(url)
elif mode==2:
        print ""+url
        LISTELE2(url)
elif mode==3:
        print ""+url
        LISTELE3(url)
elif mode==4:
        print ""+url
        BOLUMLER(url,name)

elif mode==5:
        print ""+url
        VIDEOLINKS(url,name)

elif mode==6:
        oynat(url,name)

elif mode==7:
        print ""+url
        SONVID(url,name)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
