﻿# -*- coding: utf-8 -*-
import sys
from urllib import urlencode
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin
import requests, re

reload(sys)  
sys.setdefaultencoding('utf8')

_url = sys.argv[0]
_handle = int(sys.argv[1])
dir = xbmcplugin.endOfDirectory

baseurl = 'https://www.trtizle.com'
api = 'https://public-api.trt.sh/trttv/v3'
header = {'Referer': baseurl, 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36', 'Accept-Encoding': 'gzip'}

def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))
    
def get_json(url):
    req = requests.get(api + '/{0}'.format(url))
    data = req.json()
    return data

class Item:
    name = None
    url = None
    thumb = "special://home/addons/plugin.video.trt/icon.png"
    description = None
    fanart = "special://home/addons/plugin.video.trt/fanart.jpg"
    icon = None
    poster = None
    banner = None
    date = None
    duration = None
    cast = ""
    status = None
    category = None
    season = None
    episode = None


def list_index():
    names = ['Diziler', 'Programlar', 'Belgesel', 'Müzik', 'Çocuk']
    urls = ['category/diziler', 'category/programlar', 'category/belgesel', 'category/muzik', 'category/cocuk']
    for name, url in zip(names, urls):
        list_index = []
        item = Item()
        item.name = str(name)
        item.url = str(url)
        list_index.append(item)
        list_items('list_category', list_index)

    list_live = []
    item = Item()
    item.name = "Canlı"
    list_live.append(item)
    list_items('list_live', list_live)
    list_latest = []
    item = Item()
    item.name = "Son Videolar"
    item.url = "homepage"
    list_latest.append(item)
    list_items("list_latest_videos", list_latest)
    list_search = []
    item = Item()
    item.name = "Arama"
    list_search.append(item)
    list_items("search", list_search)
    dir(_handle)


def list_category(url):
    data = get_json(url)
    for category in data['components']:
        category_items = []
        item = Item()
        item.name = category['title']
        item.url = url
        item.category = category['orderNo']
        category_items.append(item)
        list_items("list_sub_category", category_items)
    dir(_handle)

 
def list_sub_category(category, url):
    data = get_json(url)
    for a in data['components']:
        orderNo = a['orderNo']
        if orderNo == int(category):
            for x in a['contents']:
                fanart2 = x['show']['mainImageWithLogoUrl']
                sub_category_items = []
                item = Item()
                item.name = x['show']['title']
                item.url = 'show/' + x['show']['showKey'] + '?limit=1000'
                item.description = x['show']['description']
                item.banner = x['show']['coverImageUrl']
                item.fanart = x['show']['mainImageUrl']
                item.poster = x['show']['verticalImageUrl']
                sub_category_items.append(item)
                list_items("list_episodes", sub_category_items)
    dir(_handle)


def list_episodes(url):
    data = get_json(url)
    fanart = data['show']['mainImageUrl']
    banner = data['show']['coverImageUrl']
    for a in reversed(data['videos']['contents']):
        episode_items = []
        item = Item()
        item.name = a['title']
        item.description = a['description']
        item.thumb = item.poster = a['mainImageUrl']
        item.season = a['season']
        item.episode = a['episode']
        item.duration = a['duration']
        item.date = a['publishedDate']
        item.url = 'video?path=' + a['path']
        item.banner = banner
        #item.poster = data['show']['verticalImageUrl']
        item.fanart = fanart
        episode_items.append(item)
        list_items("list_videos", episode_items)
        
    dir(_handle)


def list_videos(url):
    data = get_json(url)
    video = data['video']
    show = data['show']
    fanart = show['mainImageUrl']
    banner = show['coverImageUrl']

    if video['mp4Url']:
        video_item1 = []
        item = Item()
        item.name =  video['title'] + ' · ► mp4'
        item.url = video['mp4Url']
        item.thumb = item.poster = video['mainImageUrl']
        item.description = video['description']
        item.fanart = fanart
        item.banner = banner
        item.date = video['publishedDate']
        item.duration = video['duration']
        item.season = video['season']
        item.episode = video['episode']
        video_item1.append(item)
        list_items("play", video_item1)
        
    if video['hlsUrl']:
        video_item2 = []
        item = Item()
        item.name = video['title'] + ' · ► hls'
        item.url = video['hlsUrl']
        item.thumb = item.poster = video['mainImageUrl']
        item.description = video['description']
        item.fanart = fanart
        item.banner = banner
        item.date = video['publishedDate']
        item.duration = video['duration']
        item.season = video['season']
        item.episode = video['episode']
        video_item2.append(item)
        list_items("play", video_item2)
        
    if video['youtubeId']:
        video_item3 = []
        item = Item()
        item.name = video['title'] + ' · ► YouTube'
        item.url = video['youtubeId']
        item.thumb = item.poster = video['ytThumbnailUrl']
        item.description = video['description']
        item.fanart = fanart
        item.banner = banner
        item.date = video['publishedDate']
        item.duration = video['duration']
        item.season = video['season']
        item.episode = video['episode']
        video_item3.append(item)
        list_items("play", video_item3)

    if 'nextEpisode' in data:
        a = data['nextEpisode']
        next_item = []
        item = Item()
        item.name = '[I]Sonraki Bölüm: {}[/I]'.format(a['title'])
        item.url = 'video?path={}'.format(a['path'])
        item.thumb = a['mainImageUrl']
        item.description = a['description']
        item.fanart = fanart
        item.banner = banner
        item.date = a['publishedDate']
        item.duration = a['duration']
        item.season = a['season']
        item.episode = a['episode']
        next_item.append(item)
        list_items("list_videos", next_item)
        
    serie_index = []
    item = Item()
    item.name = '[I]{} Tüm Bölümleri[/I]'.format(show['title'])
    item.url = 'show/{}?limit=1000'.format(show['showKey'])
    item.thumb = show['verticalImageUrl']
    item.description = show['description']
    item.fanart = fanart
    serie_index.append(item)
    list_items("list_episodes", serie_index)
    
    home = []
    item = Item()
    item.name = '[I]Ana Menü[/I]'
    item.description = 'Ana Menü\'ye Git'
    home.append(item)
    list_items("gotohome", home)   
    

    dir(_handle)


def list_live():
    names = ['TV', 'Radyo', 'EBA TV']
    urls = ['tv', 'radyo', 'edu']
    for name, url in zip(names, urls):
        list_index = []
        item = Item()
        item.name = str(name)
        item.url = str(url)
        list_index.append(item)
        list_items('live_channels', list_index)
    dir(_handle)
    
def live_channels(url):
    req = requests.get('https://www.trtizle.com/api/live?path=/canli/tv/trt-1')
    data = req.json()
    
    if url == 'tv':
        cond = data['tvChannels']
    if url == 'radyo':
        cond = data['radioChannels']
    if url == 'edu':
        cond = data['eduChannels']
    
    for channels in cond:
        list_index = []
        item = Item()   
        item.name = channels['title']
        item.url = channels['url']
        item.thumb = channels['square_logo']
#        item.thumb = channels['thumbnail']
        item.fanart = channels['thumbnailYoutubeUrl']
        list_index.append(item)
        list_items('play', list_index)
   
    dir(_handle)
    
def list_latest_videos(url):
    data = get_json(url)
    h = data['headline']['video']

    headline = []
    item = Item()
    item.name = h['title']
    item.url = 'video?path={}'.format(h['path'])
    item.thumb = item.poster = item.fanart = h['mainImageUrl']
    item.description = h['description']
    item.duration = h['duration']
    item.season = h['season']
    item.episode = h['episode']
    item.date = h['publishedDate']
    headline.append(item)
    list_items("list_videos", headline)

    for a in data['latest']:
        b = a['video']
        last_item = []
        item = Item()
        item.name  = b['title']
        item.url = 'video?path={}'.format(b['path'])
        item.thumb = item.poster = item.fanart = b['mainImageUrl']
        item.description = b['description']
        item.duration = b['duration']
        item.season = b['season']
        item.episode = b['episode']
        item.date = b['publishedDate']
        last_item.append(item)
        list_items("list_videos", last_item)
        
    dir(_handle)
    
def search(url):
    term = ""
    keyboard = xbmc.Keyboard('', "Arama", False)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        term = keyboard.getText()
        term = 'search/{}?limit=10'.format(term)
        #term = str(urllib.quote(term))
        data = get_json(term)

        for s in data['shows']:
            search = []
            item = Item()
            item.name = 'Yapım  : {}'.format(s['show']['title'])
            item.url = 'show/{}?limit=1000'.format(s['show']['showKey'])
            item.thumb = item.poster = s['show']['verticalImageUrl']
            item.description = s['show']['metaDescription']
            item.fanart = s['show']['mainImageUrl']
            item.banner = s['show']['coverImageUrl']
            search.append(item)
            list_items("list_episodes", search)

        for e in data['episodes']:
            search = []
            item = Item()
            item.name = 'Bölüm : {}'.format(e['cmsTitle'])
            item.url = 'video?path={}'.format(e['path'])
            item.thumb = item.poster = item.fanart = e['mainImageUrl']
            item.description = e['description']
            item.duration = e['duration']
            item.season = e['season']
            item.episode = e['episode']
            item.date = e['publishedDate']
            search.append(item)
            list_items("list_videos", search)
        dir(_handle)



def list_items(action, items):
    for item in items:
        try:
            premiered = re.compile('(\d{4}-\d{2}-\d{2})').findall(item.date)[0]
            year = re.compile('(\d{4})').findall(item.date)[0]
        except:
            premiered = year = None
        title = re.sub("\s\d+\..*", "", item.name)
        list_item = xbmcgui.ListItem(label=item.name)
        list_item.setInfo(type='Video', infoLabels={'title': title, 'originaltitle': '', 'plot': item.description, 'year': year, 'premiered': premiered, 'duration': item.duration, 'cast': list(item.cast), 'status': item.status, 'season': item.season, 'episode': item.episode, 'mediatype': 'tvshow'})
        list_item.setArt({'thumb': item.thumb, 'icon': item.icon, 'fanart': item.fanart, 'banner': item.banner, 'poster': item.poster})
        xbmcplugin.setContent(_handle, 'tvshows')
        url = get_url(action=action, url=item.url, name=item.name, category=item.category)
        if action == "play":
            list_item.setProperty('IsPlayable', 'true')
        is_folder = not action == "play"
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)


def play_video(path):
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        action = params['action']
        name = params['name']
        url = params['url']
        category = params['category']
    
        if action == 'list_category':
            list_category(url)
        elif action == 'list_sub_category':
            list_sub_category(category, url)
        elif action == 'list_episodes':
            list_episodes(url)
        elif action == 'list_videos':
            list_videos(url)
        elif action == 'gotohome':
            list_index()
        elif action == 'list_live':
            list_live()
        elif action == 'live_channels':
            live_channels(url)
        elif action == 'list_latest_videos':
            list_latest_videos(url)
        elif action == 'search':
            search(url)
        elif action == 'play':
            play_video(url)
        else:
            raise ValueError('Invalid paramstring: {0}'.format(paramstring))

    else:
        list_index()


if __name__ == '__main__':
    router(sys.argv[2][1:])
