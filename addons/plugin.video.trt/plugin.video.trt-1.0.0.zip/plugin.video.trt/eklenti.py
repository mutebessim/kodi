﻿# -*- coding: utf-8 -*-
import xbmcplugin, xbmcaddon, requests, re, base64
import xbmc, urllib

_handle = int(sys.argv[1])
siteyolu = 'http://service.trt.erstream.com/api/'
imgyolu = 'http://img.trt.tv/'
canliurl = 'http://www.trt.net.tr/Anasayfa'
trturl = 'http://www.trt.tv/'
simge = 'special://home/addons/plugin.video.trt/icon.png'
fanart1 = 'special://home/addons/plugin.video.trt/fanart.jpg'
fanart2 = 'https://i.hizliresim.com/W0ODJ2.png'
fanart3 = 'https://i.hizliresim.com/P0bDXN.jpg'
ayarlar = xbmcaddon.Addon().getSetting
blimit = ayarlar("blimit")
sort = ayarlar("sort")


def ANA():
    liste(dil(1), siteyolu + "GetCategoriesByTag", "diziler", "parentId%5B%5D=2&tag=&sortOption=Order&sortDirection=ASC&count=200&pageIndex=0&checkActive=true&mustHaveItem=true", simge, "", fanart1)
    liste(dil(2), siteyolu + "GetCategoriesByTag", "diziler", "parentId%5B%5D=20149&tag=&sortOption=Order&sortDirection=ASC&count=200&pageIndex=0&checkActive=true&mustHaveItem=true", simge, "", fanart1)
    liste(dil(3), siteyolu + "GetCategoriesByTag", "diziler", "parentId%5B%5D=20153&tag=&sortOption=Order&sortDirection=ASC&count=200&pageIndex=0&checkActive=true&mustHaveItem=true", simge, "", fanart1)
    liste(dil(4), siteyolu + "GetCategoriesByTag", "diziler", "parentId%5B%5D=20157&tag=&sortOption=Order&sortDirection=ASC&count=200&pageIndex=0&checkActive=true&mustHaveItem=true", simge, "", fanart1)
    liste(dil(5), siteyolu + "GetCategoriesByTag", "diziler", "parentId%5B%5D=80296&tag=&sortOption=Order&sortDirection=ASC&count=200&pageIndex=0&checkActive=true&mustHaveItem=true", simge, "", fanart1)
    liste(dil(6), canliurl + "/canli.aspx?y=tv&k=trt1", "canli", "", simge, "", fanart1)
    liste(dil(10), canliurl + "/canli.aspx?y=radyo&k=radyo1", "canlir", "", simge, "", fanart1)
    liste(dil(11), "", "yeniler", "", simge, "", fanart1)
    liste(dil(12), siteyolu + "GetItemResults", "arama", '&sortDirection=DESC&sortOption=CreateDate&count='  + str(blimit) +  '&pageIndex=1', simge, "", fanart1)


def diziler(url, postdata):
    veri = requests.post(url, data=postdata)
    veri = veri.json()

    for items in veri:
        isim = items['Name'].encode('utf-8')
        resimler = items['Images']
        fanart = re.compile('<Poster>(.+?)</Poster>').findall(resimler)
        fanart = imgyolu + ''.join(fanart)
        banner = re.compile('<Wide>(.+?)</Wide>').findall(resimler)
        banner = imgyolu + ''.join(banner)
        thumb = re.compile('<Thumbnail>(.+?)</Thumbnail>').findall(resimler)
        thumb = imgyolu + ''.join(thumb)
        try:
            Id = items['Tags'][0]['CategoryId']
        except:
            for tags in items['Tags']:
                Id = tags['CategoryId']
        tarih = items['CreateDate']
        pdata = 'categories%5B%5D=' + str(Id) + '&genres%5B%5D=1&direction=' + sort + '&type=Custom&pageIndex=0&count=' + str(blimit) + '&customSortField=bolum_sirasi'

        liste(isim, siteyolu + 'GetFilteredVideos', "bolumler", pdata, thumb, "", fanart, banner, fanart, "", "", tarih)


def bolumler(url, postdata, fanart, banner):
    veri = requests.post(url, data=postdata)
    veri = veri.json()
    toplam = veri['TotalCount']

    tsayfa = toplam / int(blimit) - 1
    pindex = re.sub(r'.+?pageIndex=(\d+?).+', r'\1', postdata)  # Postdata'dan mevcut PageIndex'i tespit et
    pid = re.sub(r'categories%5B%5D=(\d+?)&.+', r'\1', postdata)  # Postdata'dan mevcut Id'yi tespit et

    for items in veri['Items']:
        isim = items['Name'].encode('utf-8')
        aciklama = items['Description'].encode('utf-8')
        aciklama = re.sub('<[^<]+?>', '', aciklama)
        tarih = items['CreateDate']
        thumb = imgyolu + items['ImageList'][0]['ImageUrl']
        yonetmen = items['CustomAttributes']['yonetmen']['Value']
        yapimci = items['CustomAttributes']['yapimci']['Value']
        oyuncular = items['CustomAttributes']['oyuncular']['Value']
        if oyuncular: oyuncular = oyuncular.split(',')
        Url = items['EncodedURL']
        Id = items['Id']
        link = trturl + "izle/" + str(Id) + "/" + Url + "/"
        sure = int(items['Duration'])

        liste(isim, link, "video", "", thumb, aciklama, fanart, banner, fanart, yonetmen, oyuncular, tarih, yapimci, sure)

    if pindex <= str(tsayfa):
        ileri = int(pindex) + 1
        next = int(pindex) + 2
        data = 'categories%5B%5D=' + str(pid) + '&genres%5B%5D=1&direction=' + sort + '&type=Custom&pageIndex=' + str(ileri) + '&count=' + str(blimit) + '&customSortField=bolum_sirasi'
        sonraki = "[I]" + dil(9) + " (" + str(next) + ")[/I]"
        liste(sonraki, siteyolu + 'GetFilteredVideos', "bolumler", data, "")


def Video(url, fanart, banner, sure, tarih):
    veri = requests.get(url)
    veri = veri.text
    veri = degistir(veri)
    link = re.compile('url: "(.+?);').findall(veri)
    aciklama = re.compile('<div style="margin-left: 15px;">.+?<strong>\r\n\s+(.+?)\s+</strong>', re.DOTALL).findall(veri)
    thumb = re.compile('<meta name="thumbnail" content="(.+?)" />').findall(veri)
    yonetmen = re.compile('.+?<b>Y\xf6netmen : </b> (.+?)\r').findall(veri)
    yapimci = re.compile('<span class="productor">.+?<strong><b>.+?</b>(.+?)</strong>', re.DOTALL).findall(veri)
    oyuncular = re.compile('<span><strong><b>Oyuncular : </b></strong></span>\r\n.+?<strong>\r\n\s+(.+?)\r\n\s+</strong>', re.DOTALL).findall(veri)
    if oyuncular: oyuncular = oyuncular[0].split(',')
    if yonetmen: yonetmen = yonetmen[0]
    if yapimci: yapimci = yapimci[0]

    if link:
        goruntu(name, link[0], "oynat", thumb[0], aciklama[0], fanart, banner, fanart, yonetmen, oyuncular, tarih, yapimci, sure)


def canlilistele(url):
    veri = requests.get(url)
    if veri:
        link = re.compile('\(dcm1\("(.+?)"').findall(veri.text)
        m3u8 = re.compile('var prmf1 = "(.+?)"').findall(base64.b64decode(link[0]))
        try:
            resim = re.compile('var prmim = "(.+?)";').findall(base64.b64decode(link[0]))
            resim = resim[0]
        except:
            resim = "http://www.trt.net.tr/images2012/trt_radyo_player_gorsel.png"
        try:
            title = re.compile('<title>(.+?)</title>').findall(veri.text)
            title = title[0]
        except:
            title = re.compile('prmti="(.+?)"').findall(veri.text)
            title = re.sub(r'(.+?) Kanal.+', r'\1', title[0])
            title = title
        try:
            baslik = re.sub(r'(.+?) - Canl.+', r'\1', title)
        except:
            baslik = ""
        Ok = True
        goruntu(baslik, m3u8[0], 'oynat', resim, title, fanart2)
        return Ok


def canli(url):
    veri = requests.get(url)
    eslesen = re.compile('<ul id="tvKanalSecim">(.+?)</ul>', re.DOTALL).findall(veri.text)
    eslesen = re.compile('<li><a href=".(.+?)"').findall(eslesen[0])

    for eslesen in eslesen:
        eslesen = canliurl + eslesen
        canlilistele(eslesen)


def canlir(url):
    veri = requests.get(url)
    eslesen = re.compile('<ul id="radyoKanalSecim">(.+?)</ul>', re.DOTALL).findall(veri.text)
    eslesen = re.compile('<li><a href=".(.+?)"').findall(eslesen[0])

    for eslesen in eslesen:
        eslesen = canliurl + eslesen
        canlilistele(eslesen)


def yeniler():
    veri = requests.get(trturl)
    veri = veri.text
    veri = degistir(veri)
    eslesen = re.compile('<div class="container">(.+?)<!-- Yeniler  Small -->', re.DOTALL).findall(veri)
    link = re.compile('<a href="(.+?)" class=".+?">').findall(eslesen[0])
    thumb = re.compile('<img src="(.+?)" w').findall(eslesen[0])
    isim = re.compile('<h5 class="video_name" title="(.+?)">').findall(eslesen[0])
    tarih = re.compile('<span class="publish_date">(.+?)</span>').findall(eslesen[0])

    for link, thumb, isim, tarih in zip(link, thumb, isim, tarih):
        thumb = re.sub(r'(\d+?)x(\d+?)/', '600x350/', thumb)
        isim = isim.encode('utf-8')
        liste(isim, trturl + link, "video", "", thumb, tarih)


def arama(url, postdata):
    kontrol = re.compile('.+&pageIndex=(\d+?)$').findall(postdata)
    next = int(kontrol[0]) + 1

    if kontrol[0] == "1":
        keyboard = xbmc.Keyboard('', dil(18), False)
        keyboard.doModal()
        if (keyboard.isConfirmed()):
            aramaterimi = keyboard.getText()
            querystring = str(urllib.quote(aramaterimi))
            post = "text=" + querystring + postdata
            veri = requests.post(url, data=post)
            veri = veri.json()
            toplam = veri['TotalCount'] / int(blimit)

            for items in veri['Items']:
                isim = items['Name'].encode('utf-8')
                aciklama = items['Description'].encode('utf-8')
                tarih = items['CreateDate']
                thumb = imgyolu + items['ImageList'][0]['ImageUrl']
                Url = items['EncodedURL']
                Id = items['Id']
                link = trturl + "izle/" + str(Id) + "/" + Url + "/"
                liste(isim, link, "video", "", thumb, aciklama, fanart1, "", "", "", "", tarih)

            if toplam > 0:
                spost = re.sub(r'&pageIndex=\d+?', '', post)
                spost = spost + "&pageIndex=" + str(next)
                sonraki = "[I]" + dil(9) + " (" + str(next) + ")[/I]"
                liste(sonraki, siteyolu + "GetItemResults", "arama", spost, "")

    else:
        veri = requests.post(url, data=postdata)
        veri = veri.json()

        toplam = veri['TotalCount'] / int(blimit) + 1

        for items in veri['Items']:
            isim = items['Name'].encode('utf-8')
            aciklama = items['Description'].encode('utf-8')
            tarih = items['CreateDate']
            thumb = imgyolu + items['ImageList'][0]['ImageUrl']
            Url = items['EncodedURL']
            Id = items['Id']
            link = trturl + "izle/" + str(Id) + "/" + Url + "/"
            liste(isim, link, "video", "", thumb, aciklama, fanart1, "", "", "", "", tarih)

        if next <= toplam:
            spost = re.sub(r'&pageIndex=\d+?$', '', postdata)
            spost = spost + "&pageIndex=" + str(next)
            sonraki = "[I]" + dil(9) + " (" + str(next) + ")[/I]"
            liste(sonraki, siteyolu + "GetItemResults", "arama", spost, "")


from resources.lib import arac

mode = arac.mode
name = arac.name
url = arac.url
postdata = arac.postdata
fanart = arac.fanart
banner = arac.banner
sure = arac.sure
tarih = arac.tarih
liste = arac.liste
goruntu = arac.goruntu
oynat = arac.oynat
dil = arac.dil
degistir = arac.degistir

if mode == 'diziler':
    diziler(url, postdata)
elif mode == 'bolumler':
    bolumler(url, postdata, fanart, banner)
elif mode == 'video':
    Video(url, fanart, banner, sure, tarih)
elif mode == 'canli':
    canli(url)
elif mode == 'canlir':
    canlir(url)
elif mode == 'yeniler':
    yeniler()
elif mode == 'arama':
    arama(url, postdata)
elif mode == 'oynat':
    oynat(url)
else:
    ANA()
xbmcplugin.endOfDirectory(_handle)
