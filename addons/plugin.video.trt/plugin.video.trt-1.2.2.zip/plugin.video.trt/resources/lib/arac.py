import sys, urllib
import xbmcplugin, xbmcgui, xbmcaddon
_url = sys.argv[0]
_handle = int(sys.argv[1])

def dil(yazi):
    return xbmcaddon.Addon().getLocalizedString(yazi).encode('utf-8')


def degistir(girdi):
    girdi = girdi.replace('&#252;', u'\xfc').replace('&#220;', u'\xdc').replace('&#214;', u'\xd6').replace('&#246;', u'\xf6').replace('&#231;', u'\xe7').replace('&#199;', u'\xc7')
    girdi = girdi.replace('&quot;', '"').replace('&#39;', '\'')
    return girdi


def parameters_string_to_dict(parameters):
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split('&')
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if len(paramSplits) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]

    return paramDict


def oynat(url):
    url = str(url).encode('utf-8', 'ignore')
    play_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def goruntu(name, url, mode, thumb, aciklama, fanart = '', banner = '', poster = '', director = '', cast = '', tarih = '', studyo = '', sure = ''):
    url = _url + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode)
    if not fanart:
        fanart = thumb
    if not poster:
        poster = thumb
    ok = True
    list_item = xbmcgui.ListItem(label=name)
    list_item.setInfo(type='Video', infoLabels={'title': name,
     'plot': aciklama,
     'director': director,
     'thumb': thumb,
     'duration': sure,
     'premiered': tarih,
     'studio': studyo})
    if cast:
        list_item.setInfo(type='Video', infoLabels={'cast': list(cast)})
    list_item.setArt({'thumb': thumb,
     'fanart': fanart,
     'poster': poster,
     'banner': banner})
    list_item.setProperty('IsPlayable', 'true')
    is_folder = False
    xbmcplugin.setContent(_handle, 'episodes')
    xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    return ok


def liste(name, url, mode, postdata, thumb, aciklama = '', fanart = '', banner = '', poster = '', director = '', cast = '', tarih = '', studyo = '', sure = ''):
    url = _url + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&postdata=' + urllib.quote_plus(postdata) + '&fanart=' + urllib.quote_plus(fanart) + '&banner=' + urllib.quote_plus(banner) + '&sure=' + str(sure) + '&tarih=' + tarih
    if not fanart:
        fanart = thumb
    if not poster:
        poster = thumb
    ok = True
    list_item = xbmcgui.ListItem(label=name)
    list_item.setArt({'poster': poster,
     'banner': banner,
     'fanart': fanart,
     'thumb': thumb})
    list_item.setInfo(type='Video', infoLabels={'title': name,
     'plot': aciklama,
     'director': director,
     'studio': studyo,
     'duration': sure})
    if tarih:
        list_item.setInfo(type='Video', infoLabels={'premiered': tarih})
    if cast:
        list_item.setInfo(type='Video', infoLabels={'cast': list(cast)})
    is_folder = True
    xbmcplugin.setContent(_handle, 'episodes')
    xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    return ok


params = parameters_string_to_dict(sys.argv[2])
mode = urllib.unquote_plus(params.get('mode', ''))
url = urllib.unquote_plus(params.get('url', ''))
name = urllib.unquote_plus(params.get('name', ''))
postdata = urllib.unquote_plus(params.get('postdata', ''))
fanart = urllib.unquote_plus(params.get('fanart', ''))
banner = urllib.unquote_plus(params.get('banner', ''))
sure = urllib.unquote_plus(params.get('sure', ''))
tarih = urllib.unquote_plus(params.get('tarih', ''))