# -*- coding: utf-8 -*-
import os
from os import path
from datetime import datetime, timedelta
import requests, json, xbmcvfs

anadizin = os.path.abspath(os.path.dirname(__file__))

dosya = anadizin + '/token.json'
apikey = 'OUM4NEE0QzZGMTdFMUI1OA=='.decode('base64')
userkey = 'Q0JGMEQxNDJFNTNFMEFDQw=='.decode('base64')


def apitoken():
    url = "https://api.thetvdb.com/login"
    postdata = {
        "apikey": apikey,
        "userkey": userkey,
        "username": "kralkodi"
    }
    header = {'Content-Type': 'application/json', 'Accept': 'application/json'}

    veri = requests.post(url, data=json.dumps(postdata), headers=header)
    veri = veri.text

    data = xbmcvfs.File(dosya, 'w+')
    data.write(str(veri))


if not os.path.exists(dosya):
    apitoken()

one_day_ago = datetime.now() - timedelta(hours=1)
filetime = datetime.fromtimestamp(path.getmtime(dosya))

if filetime < one_day_ago:
    apitoken()

with open(dosya) as jveri:
    verim = []
    data = json.load(jveri)
    token = data['token']
    verim.append(token)

token = 'Bearer ' + token


class Bilgi:
    name = None
    url = None
    thumb = None
    description = None
    fanart = None
    icon = None
    poster = None
    banner = None
    date = None
    serieid = None
    duration = None
    cast = ""


def dizi_arat(query):
    header = {'Accept': 'application/json', 'Accept-Language': 'tr', 'Authorization': token}
    arat = requests.get("https://api.thetvdb.com/search/series?name=" + query, headers=header)
    data = arat.json()
    return data


def dizi_detay(id):
    header = {'Accept': 'application/json', 'Accept-Language': 'tr', 'Authorization': token}
    arat = requests.get("https://api.thetvdb.com/series/" + str(id), headers=header)
    data = arat.json()
    return data


def oyuncu_detay(id):
    header = {'Accept': 'application/json', 'Accept-Language': 'tr', 'Authorization': token}
    arat = requests.get("https://api.thetvdb.com/series/" + str(id) + "/actors", headers=header)
    data = arat.json()
    return data


def dizi_materyal(id, keyType):  # keyType fanart, poster
    header = {'Accept': 'application/json', 'Accept-Language': 'tr', 'Authorization': token}
    arat = requests.get("https://api.thetvdb.com/series/" + str(id) + "/images/query?keyType=" + keyType, headers=header)
    data = arat.json()
    if 'data' in data:
        for data in data['data']:
            resim = data['fileName']
            return "http://thetvdb.com/banners/" + resim
