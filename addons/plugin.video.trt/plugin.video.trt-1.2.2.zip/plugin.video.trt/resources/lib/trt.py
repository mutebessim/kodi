# -*- coding: utf-8 -*-
import xbmcaddon, requests, re, base64
import xbmc, urllib, arac
import logging
from multiprocessing.dummy import Pool as ThreadPool

try:
    import tvdb
except:
    pass
siteyolu = 'http://service.trt.erstream.com/api/'
imgyolu = 'http://img.trt.tv/'
canliurl = 'http://www.trt.net.tr/Anasayfa'
trturl = 'http://www.trt.tv/'
simge = 'special://home/addons/plugin.video.trt/icon.png'
fanart1 = 'special://home/addons/plugin.video.trt/fanart.jpg'
fanart2 = 'https://i.hizliresim.com/W0ODJ2.png'
fanart3 = 'https://i.hizliresim.com/P0bDXN.jpg'
ayarlar = xbmcaddon.Addon().getSetting
blimit = ayarlar('blimit')
sort = ayarlar('sort')
header = {'Referer': trturl,
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'}
mode = arac.mode
name = arac.name
url = arac.url
postdata = arac.postdata
fanart = arac.fanart
banner = arac.banner
sure = arac.sure
tarih = arac.tarih
liste = arac.liste
goruntu = arac.goruntu
oynat = arac.oynat
dil = arac.dil
degistir = arac.degistir


def ANA():
    liste(dil(1), siteyolu + 'GetCategoriesByTag', 'diziler', 'parentId%5B%5D=2&tag=&sortOption=Order&sortDirection=ASC&count=200&pageIndex=0&checkActive=true&mustHaveItem=true', simge, '', fanart1)
    liste(dil(2), siteyolu + 'GetCategoriesByTag', 'diziler', 'parentId%5B%5D=20149&tag=&sortOption=Order&sortDirection=ASC&count=200&pageIndex=0&checkActive=true&mustHaveItem=true', simge, '', fanart1)
    liste(dil(3), siteyolu + 'GetCategoriesByTag', 'diziler', 'parentId%5B%5D=20153&tag=&sortOption=Order&sortDirection=ASC&count=200&pageIndex=0&checkActive=true&mustHaveItem=true', simge, '', fanart1)
    liste(dil(4), siteyolu + 'GetCategoriesByTag', 'diziler', 'parentId%5B%5D=20157&tag=&sortOption=Order&sortDirection=ASC&count=200&pageIndex=0&checkActive=true&mustHaveItem=true', simge, '', fanart1)
    liste(dil(5), siteyolu + 'GetCategoriesByTag', 'diziler', 'parentId%5B%5D=80296&tag=&sortOption=Order&sortDirection=ASC&count=200&pageIndex=0&checkActive=true&mustHaveItem=true', simge, '', fanart1)
    liste(dil(6), canliurl + '/canli.aspx?y=tv&k=trt1', 'canli', '', simge, '', fanart1)
    liste(dil(10), canliurl + '/canli.aspx?y=radyo&k=radyo1', 'canlir', '', simge, '', fanart1)
    liste(dil(11), '', 'yeniler', '', simge, '', fanart1)
    liste(dil(12), siteyolu + 'GetItemResults', 'arama', '&sortDirection=DESC&sortOption=CreateDate&count=' + str(blimit) + '&pageIndex=1', simge, '', fanart1)


def diziler(url, postdata):
    veri = requests.post(url, data=postdata, headers=header)
    veri = veri.json()

    try:  # tvdb modulu calisiyorsa
        isimler = []
        for x in veri:
            a = x['Name'].encode('utf-8')
            isimler.append(a)

        logging.basicConfig(level=logging.DEBUG)
        pool = ThreadPool(50)
        tvdbinfos = pool.map(tvdb.dizi_arat, isimler)
        pool.close()
        pool.join()

        # descriptions = []; dates = []; banners = []; ids = []; statuses = []
        descriptions = []

        for tvdbinfo in tvdbinfos:
            if 'data' in tvdbinfo:
                a = tvdbinfo['data'][0]['overview']
                # b = tvdbinfo['data'][0]['firstAired']
                # c = tvdbinfo['data'][0]['banner']
                # d = tvdbinfo['data'][0]['id']
                # e = tvdbinfo['data'][0]['status']
            else:
                # a = b = c = d = e = None
                a = None
            descriptions.append(a)
            # dates.append(b)
            # banners.append(c)
            # ids.append(d)
            # statuses.append(e)
    except:  # tvdb modulu calismiyorsa
        descriptions = []
        for x in veri:
            a = x['Name'].encode('utf-8')
            descriptions.append(a)

    for items, aciklama in zip(veri, descriptions):
        isim = items['Name'].encode('utf-8')
        resimler = items['Images'].lower()
        fanart = re.compile('<poster>(.+?)</poster>').findall(resimler)
        fanart = imgyolu + ''.join(fanart)
        fanart = fanart.encode('utf-8')
        banner = re.compile('<wide>(.+?)</wide>').findall(resimler)
        banner = imgyolu + ''.join(banner)
        thumb = re.compile('<thumbnail>(.+?)</thumbnail>').findall(resimler)
        thumb = imgyolu + ''.join(thumb)
        try:
            Id = items['Tags'][0]['CategoryId']
        except:
            for tags in items['Tags']:
                Id = tags['CategoryId']

        tarih = items['CreateDate']
        pdata = 'categories%5B%5D=' + str(Id) + '&genres%5B%5D=1&direction=' + sort + '&type=Custom&pageIndex=0&count=' + str(blimit) + '&customSortField=bolum_sirasi'
        liste(isim, siteyolu + 'GetFilteredVideos', 'bolumler', pdata, thumb, aciklama, fanart, banner, fanart, '', '', tarih)


def bolumler(url, postdata, fanart, banner):
    veri = requests.post(url, data=postdata, headers=header)
    veri = veri.json()
    toplam = veri['TotalCount']
    tsayfa = toplam / int(blimit) - 1
    pindex = re.sub('.+?pageIndex=(\\d+?).+', '\\1', postdata)
    pid = re.sub('categories%5B%5D=(\\d+?)&.+', '\\1', postdata)
    for items in veri['Items']:
        isim = items['Name'].encode('utf-8')
        aciklama = items['Description'].encode('utf-8')
        aciklama = re.sub('<[^<]+?>', '', aciklama)
        tarih = items['CreateDate']
        thumb = imgyolu + items['ImageList'][0]['ImageUrl']
        yonetmen = items['CustomAttributes']['yonetmen']['Value']
        yapimci = items['CustomAttributes']['yapimci']['Value']
        oyuncular = items['CustomAttributes']['oyuncular']['Value']
        if oyuncular:
            oyuncular = oyuncular.split(', ')
        Url = items['EncodedURL']
        Id = items['Id']
        link = trturl + 'izle/%d/%s/' % (Id, Url)
        sure = int(items['Duration'])
        liste(isim, link, 'video', '', thumb, aciklama, fanart, banner, fanart, yonetmen, oyuncular, tarih, yapimci, sure)

    if pindex <= str(tsayfa):
        ileri = int(pindex) + 1
        next = int(pindex) + 2
        data = 'categories%5B%5D=' + str(pid) + '&genres%5B%5D=1&direction=' + sort + '&type=Custom&pageIndex=' + str(ileri) + '&count=' + str(blimit) + '&customSortField=bolum_sirasi'
        sonraki = '[I]' + dil(9) + ' (' + str(next) + ')[/I]'
        liste(sonraki, siteyolu + 'GetFilteredVideos', 'bolumler', data, '')


def Video(url, fanart, banner, sure, tarih):
    veri = requests.get(url, headers=header)
    veri = veri.text
    veri = degistir(veri)
    link = re.compile('url: "(.+?)\\?st=').findall(veri)
    aciklama = re.compile('<div style="margin-left: 15px;">.*?<strong>\n(.+?)\n</strong>', re.DOTALL).findall(veri)
    thumb = re.compile('<meta name="thumbnail" content="(.+?)" />').findall(veri)
    yonetmen = re.compile('.+?<b>Y\xf6netmen : </b> (.+?)\r').findall(veri)
    yapimci = re.compile('<span class="productor">.+?<strong><b>.+?</b>(.+?)</strong>', re.DOTALL).findall(veri)
    oyuncular = re.compile('<span><strong><b>Oyuncular : </b></strong></span>\r\n.+?<strong>\r\n\\s+(.+?)\r\n\\s+</strong>', re.DOTALL).findall(veri)
    if oyuncular:
        oyuncular = oyuncular[0].split(', ')
    if yonetmen:
        yonetmen = yonetmen[0]
    if yapimci:
        yapimci = yapimci[0]
    if link:
        goruntu(name, link[0], 'oynat', thumb[0], aciklama[0], fanart, banner, fanart, yonetmen, oyuncular, tarih, yapimci, sure)


def canlilistele(url):
    veri = requests.get(url, headers=header)
    if veri:
        link = re.compile('\\(dcm1\\("(.+?)"').findall(veri.text)
        m3u8 = re.compile('var prmf1 = "(.+?)"').findall(base64.b64decode(link[0]))
        try:
            resim = re.compile('var prmim = "(.+?)";').findall(base64.b64decode(link[0]))
            resim = resim[0]
        except:
            resim = 'http://www.trt.net.tr/images2012/trt_radyo_player_gorsel.png'

        try:
            title = re.compile('<title>(.+?)</title>').findall(veri.text)
            title = title[0]
        except:
            title = re.compile('prmti="(.+?)"').findall(veri.text)
            title = re.sub('(.+?) Kanal.+', '\\1', title[0])
            title = title

        try:
            baslik = re.sub('(.+?) - Canl.+', '\\1', title)
        except:
            baslik = ''

        Ok = True
        goruntu(baslik, m3u8[0], 'oynat', resim, title, fanart2)
        return Ok


def canli(url):
    veri = requests.get(url, headers=header)
    eslesen = re.compile('<ul id="tvKanalSecim">(.+?)</ul>', re.DOTALL).findall(veri.text)
    eslesen = re.compile('<li><a href=".(.+?)"').findall(eslesen[0])
    for eslesen in eslesen:
        eslesen = canliurl + eslesen
        canlilistele(eslesen)


def canlir(url):
    veri = requests.get(url, headers=header)
    eslesen = re.compile('<ul id="radyoKanalSecim">(.+?)</ul>', re.DOTALL).findall(veri.text)
    eslesen = re.compile('<li><a href=".(.+?)"').findall(eslesen[0])
    for eslesen in eslesen:
        eslesen = canliurl + eslesen
        canlilistele(eslesen)

    goruntu('TRT D\xc4\xb0YANET RADYO', 'http://stream.n3.noc.com.tr/cache/diyanetradyo.stream/chunklist_DVR.m3u8', 'oynat', 'http://www.trt.net.tr/images2012/trt_radyo_player_gorsel.png', 'Diyanet Radyo Dinle')


def yeniler():
    veri = requests.get(trturl, headers=header)
    veri = veri.text
    veri = degistir(veri)
    eslesen = re.compile('<div class="row mobile-top">(.*?)<div class="row" style="margin-top: 20px;">', re.DOTALL).findall(veri)
    link = re.compile('<a href="(.+?)" class=".+?">').findall(eslesen[0])
    thumb = re.compile('<img src="(.+?)" w').findall(eslesen[0])
    isim = re.compile('<h5 class="video_name" title="(.+?)">').findall(eslesen[0])
    tarih = re.compile('<span class="publish_date">(.+?)</span>').findall(eslesen[0])
    for link, thumb, isim, tarih in zip(link, thumb, isim, tarih):
        thumb = re.sub('(\\d+?)x(\\d+?)/', '600x350/', thumb)
        isim = isim.encode('utf-8')
        if not 'http://' in link:
            link = trturl + link
        liste(isim, link, 'video', '', thumb, tarih)


def arama(url, postdata):
    kontrol = re.compile('.+&pageIndex=(\\d+?)$').findall(postdata)
    next = int(kontrol[0]) + 1
    if kontrol[0] == '1':
        keyboard = xbmc.Keyboard('', dil(18), False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            aramaterimi = keyboard.getText()
            querystring = str(urllib.quote(aramaterimi))
            post = 'text=' + querystring + postdata
            veri = requests.post(url, data=post, headers=header)
            veri = veri.json()
            toplam = veri['TotalCount'] / int(blimit)
            for items in veri['Items']:
                isim = items['Name'].encode('utf-8')
                aciklama = items['Description'].encode('utf-8')
                tarih = items['CreateDate']
                thumb = imgyolu + items['ImageList'][0]['ImageUrl']
                Url = items['EncodedURL']
                Id = items['Id']
                link = trturl + 'izle/' + str(Id) + '/' + Url + '/'
                liste(isim, link, 'video', '', thumb, aciklama, fanart1, '', '', '', '', tarih)

            if toplam > 0:
                spost = re.sub('&pageIndex=\\d+?', '', post)
                spost = spost + '&pageIndex=' + str(next)
                sonraki = '[I]' + dil(9) + ' (' + str(next) + ')[/I]'
                liste(sonraki, siteyolu + 'GetItemResults', 'arama', spost, '')
    else:
        veri = requests.post(url, data=postdata, headers=header)
        veri = veri.json()
        toplam = veri['TotalCount'] / int(blimit) + 1
        for items in veri['Items']:
            isim = items['Name'].encode('utf-8')
            aciklama = items['Description'].encode('utf-8')
            tarih = items['CreateDate']
            thumb = imgyolu + items['ImageList'][0]['ImageUrl']
            Url = items['EncodedURL']
            Id = items['Id']
            link = trturl + 'izle/' + str(Id) + '/' + Url + '/'
            liste(isim, link, 'video', '', thumb, aciklama, fanart1, '', '', '', '', tarih)

        if next <= toplam:
            spost = re.sub('&pageIndex=\\d+?$', '', postdata)
            spost = spost + '&pageIndex=' + str(next)
            sonraki = '[I]' + dil(9) + ' (' + str(next) + ')[/I]'
            liste(sonraki, siteyolu + 'GetItemResults', 'arama', spost, '')
