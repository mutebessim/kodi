﻿# -*- coding: utf-8 -*-
import sys, xbmcplugin
from resources.lib import trt
from resources.lib import arac

_handle = int(sys.argv[1])
mode = arac.mode
url = arac.url
postdata = arac.postdata
fanart = arac.fanart
banner = arac.banner
sure = arac.sure
tarih = arac.tarih
oynat = arac.oynat

if mode == 'diziler':
    trt.diziler(url, postdata)
elif mode == 'bolumler':
    trt.bolumler(url, postdata, fanart, banner)
elif mode == 'video':
    trt.Video(url, fanart, banner, sure, tarih)
elif mode == 'canli':
    trt.canli(url)
elif mode == 'canlir':
    trt.canlir(url)
elif mode == 'yeniler':
    trt.yeniler()
elif mode == 'arama':
    trt.arama(url, postdata)
elif mode == 'oynat':
    oynat(url)
else:
    trt.ANA()

xbmcplugin.endOfDirectory(_handle)
