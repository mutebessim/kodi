﻿# -*- coding: utf-8 -*-
import sys, platform
import urlresolver
import urllib, urllib2, cookielib
import re, xbmcplugin, xbmcgui, xbmcaddon, xbmc

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
settings = xbmcaddon.Addon(id='plugin.video.trtarsiv')

baseurl = 'http://www.trtarsiv.com'
simge = 'special://home/addons/plugin.video.trtarsiv/icon.png'
background = "special://home/addons/plugin.video.trtarsiv/fanart2.jpg"

aramaterimi = ""


def ANA():
    addDir("Son Eklenenler", baseurl, 5, simge)
    addDir("Çok Seyredilenler", baseurl, 6, simge)
    addDir("Kişiler", baseurl + "/kisi", 1, simge)
    addDir("Zaman", baseurl + "/zaman", 1, simge)
    addDir("Yer", baseurl + "/yer", 1, simge)
    addDir("Olay", baseurl + "/olay", 1, simge)
    addDir("Programlar", baseurl + "/program", 1, simge)
    addDir("Diziler", baseurl + "/dizi", 1, simge)
    addDir("Özel Videolar", baseurl + "/klip", 1, simge)
    addDir("Arama", baseurl + "/ara?bul=", 8, simge)


def KATEGORI(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36')
    response = urllib2.urlopen(req)
    link = response.read()
    link = link.replace('&#214;', "Ö").replace('&#246;', "ö").replace('&#199;', "Ç").replace('&#220;', "Ü").replace(
        '&#252;', "ü").replace('&#231;', "ç").replace('&#39;', "'").replace('&quot;', "\"")
    response.close()
    baglanti = url
    baglanti = re.sub(r"\?.+", "", baglanti)
    match = re.compile(
        '<div id="_category_.+?" class="category_subtitle"><div><a href="(.+?)">(.+?)</a></div>').findall(link)
    match2 = re.compile(
        '<li class="next pager_element page-item">\n<a href="(.+?)" title="Sonraki" class="page-link".+?background-color:#2f2f2f"').findall(
        link)
    for link, name in match:
        addDir(name, baseurl + link, 2, simge)
    if match2:
        for sonraki in match2:
            sayi = re.sub(r"\?page=(.+?)&type=Standart", r'\1', sonraki)
            addDir("Sonraki Sayfa (" + sayi + ")", baglanti + sonraki, 1, "")
    addDir("ANA MENÜYE DÖN", "", "", simge)


def BOLUMLER(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36')
    response = urllib2.urlopen(req)
    link = response.read()
    link = link.replace('&#214;', "Ö").replace('&#246;', "ö").replace('&#199;', "Ç").replace('&#220;', "Ü").replace(
        '&#252;', "ü").replace('&#231;', "ç").replace('&#39;', "'").replace('&quot;', "\"")
    response.close()
    match = re.compile(
        '<div class=".+? item">\n<a href="(.+?)" title="(.+?)">\n<div class="image">\n<img src="(.+?)" alt=".+?"/>').findall(
        link)
    for url, name, thumbnail in match:
        addDir(name, baseurl + url, 4, thumbnail)


def BOLUMDEN(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36')
    response = urllib2.urlopen(req)
    link = response.read()
    link = link.replace('&#214;', "Ö").replace('&#246;', "ö").replace('&#199;', "Ç").replace('&#220;', "Ü").replace(
        '&#252;', "ü").replace('&#231;', "ç").replace('&#39;', "'").replace('&quot;', "\"")
    response.close()
    match = re.compile('url: "(.+?)",').findall(link)
    match2 = re.compile('<div class="ozetWrapper">\n(.+)').findall(link)
    match3 = re.compile('<meta name="thumbnail" content="(.+?)"/>').findall(link)
    match4 = re.compile('<a href="/ara/zaman/\d+?" class="filter-url">(\d+?)</a>').findall(link)
    if match4:
        tarih = match4
    else:
        tarih = " "
    if match:
        for url in match:
            for desc in match2:
                for resim in match3:
                    for tarih in tarih:
                        addLink("[COLOR green]►[/COLOR] " + name, url, resim, desc, tarih)


def ARAMA(url):
    aramaterimi = ""
    if "?bul" in url:
        keyboard = xbmc.Keyboard('', "Arama", False)
        keyboard.doModal()
        if (keyboard.isConfirmed()):
            aramaterimi = keyboard.getText()
            querystring = str(urllib.quote(aramaterimi))
            url = url + querystring

            req = urllib2.Request(url)
            req.add_header('User-Agent',
                           'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36')
            response = urllib2.urlopen(req)
            link = response.read()
            link = link.replace('&#214;', "Ö").replace('&#246;', "ö").replace('&#199;', "Ç").replace('&#220;',
                                                                                                     "Ü").replace(
                '&#252;', "ü").replace('&#231;', "ç").replace('&#39;', "'").replace('&quot;', "\"")
            response.close()
            match = re.compile(
                '<a href="(.+?)" class="video_item" title="(.+?)">\n<div class="image">\n<img src=(.+?) alt').findall(
                link)
            for url, name, thumbnail in match:
                addDir(name, baseurl + url, 4, thumbnail)


def SONVIDEOLAR(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36')
    response = urllib2.urlopen(req)
    link = response.read()
    link = link.replace('&#214;', "Ö").replace('&#246;', "ö").replace('&#199;', "Ç").replace('&#220;', "Ü").replace(
        '&#252;', "ü").replace('&#231;', "ç").replace('&#39;', "'").replace('&quot;', "\"")
    response.close()
    match = re.compile(
        '<div class="swiper-container swiper-container-lastAdded">(.+?)<div class="swiper-button-next"></div>',
        re.S).findall(link)
    for match in match:
        match2 = re.compile(
            '<a href="(.+?)" class="video_item" title="(.+?)">\n<div class="image">\n<img src="(.+?)" alt').findall(
            match)
        for url, name, thumbnail in match2:
            addDir(name, baseurl + url, 4, thumbnail)

def COKBAKILANLAR(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36')
    response = urllib2.urlopen(req)
    link = response.read()
    link = link.replace('&#214;', "Ö").replace('&#246;', "ö").replace('&#199;', "Ç").replace('&#220;', "Ü").replace(
        '&#252;', "ü").replace('&#231;', "ç").replace('&#39;', "'").replace('&quot;', "\"")
    response.close()
    match = re.compile(
        '<div class="swiper-container swiper-container-mostViewed">(.+?)<div class="swiper-button-next"></div>',
        re.S).findall(link)
    for match in match:
        match2 = re.compile(
            '<a href="(.+?)" class="video_item" title="(.+?)">\n<div class="image">\n<img src="(.+?)" alt').findall(
            match)
        for url, name, thumbnail in match2:
            addDir(name, baseurl + url, 4, thumbnail)



'''
def oynat(url,name):
        playList.clear()
        url = str(url).encode('utf-8', 'ignore')


        if '.ts' in url:
                url= url
        elif 'rtmp:'  in url:
                url= url
        elif 'rtsp:'  in url:
                url= url
        elif  '.ts:' in url:
                url= url
        elif '.m3u8' in url:
                url= url
        elif '.wmv' in url:
                url= url
        elif '.mp4' in url:
                url= url
        elif '.wma' in url:
                url= url
        else:
                url=urlresolver.resolve(url)
        if url:
                addLink(name,url,'')

                listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                listitem.setInfo('video', {'name': name } )
                playList.add(str(url),listitem=listitem)
                xbmcPlayer.play(playList)
        else:
                showMessage("","[COLOR orange][B]Link bulunamadı veya ortam desteklenmiyor[/B][/COLOR]")
'''


def get_url(url):
    req = urllib2.Request(url)
    req.add_header('Referer', url)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36')
    # req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    # req.add_header('Cache-Control', 'no-transform')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def showMessage(heading='Xor', message='', times=3000, pics=''):
    try:
        xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, pics))
    except Exception, e:
        xbmc.log('[%s]: showMessage: exec failed [%s]' % ('', e), 1)


def addLink(name, url, iconimage, aciklama, tarih):
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="iconimage", thumbnailImage=iconimage)
    liz.setArt({'thumb': iconimage, 'icon': iconimage, 'fanart': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name, 'Plot': aciklama, 'Year': tarih})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=liz)
    return ok


def addDir(name, url, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setArt({'fanart': background})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok


params = get_params()
url = None
name = None
mode = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)

if mode == None or url == None or len(url) < 1:
    print ""
    ANA()
elif mode == 1:
    print "" + url
    KATEGORI(url)
elif mode == 2:
    print "" + url
    BOLUMLER(url)
elif mode == 4:
    print "" + url
    BOLUMDEN(url)
elif mode == 5:
    print "" + url
    SONVIDEOLAR(url)
elif mode == 6:
    print "" + url
    COKBAKILANLAR(url)

elif mode == 8:
    print "" + url
    ARAMA(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
