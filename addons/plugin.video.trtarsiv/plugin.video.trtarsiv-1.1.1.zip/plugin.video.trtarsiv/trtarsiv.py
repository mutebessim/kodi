﻿# -*- coding: utf-8 -*-
import sys, platform
#import urlresolver
import urllib, urllib2, cookielib
import re, xbmcplugin, xbmcgui, xbmcaddon, xbmc

settings = xbmcaddon.Addon(id='plugin.video.trtarsiv')
baseurl = 'http://www.trtarsiv.com'
simge = 'special://home/addons/plugin.video.trtarsiv/icon.png'
background = "special://home/addons/plugin.video.trtarsiv/fanart2.jpg"
_url = sys.argv[0]
_handle = int(sys.argv[1])

def getir(link):
    req = urllib2.Request(link)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36')
    req.add_header('Referer', 'http://www.trtarsiv.com')
    yanit = urllib2.urlopen(req)
    sonuc = yanit.read()
    sonuc = sonuc.replace('&#214;', "Ö").replace('&#246;', "ö").replace('&#199;', "Ç").replace('&#220;', "Ü").replace(
        '&#252;', "ü").replace('&#231;', "ç").replace('&#39;', "'").replace('&quot;', "\"")
    yanit.close()
    return sonuc

def ANA():
    liste("Son Eklenenler", baseurl, 5, simge)
    liste("Çok Seyredilenler", baseurl, 6, simge)
    liste("Kişiler", baseurl + "/kisi", 1, simge)
    liste("Zaman", baseurl + "/zaman", 1, simge)
    liste("Yer", baseurl + "/yer", 1, simge)
    liste("Olay", baseurl + "/olay", 1, simge)
    liste("Programlar", baseurl + "/program", 1, simge)
    liste("Diziler", baseurl + "/dizi", 1, simge)
    liste("Özel Videolar", baseurl + "/klip", 1, simge)
    liste("Arama", baseurl + "/ara?bul=", 8, simge)

def KATEGORI(url):
    veri = getir(url)
    baglanti = url
    baglanti = re.sub(r"\?.+", "", baglanti)
    match = re.compile(
        '<div id="_category_.+?" class="category_subtitle"><div><a href="(.+?)">(.+?)</a></div>').findall(veri)
    match2 = re.compile(
        '<li class="next pager_element page-item">\n<a href="(.+?)" title="Sonraki" class="page-link".+?background-color:#2f2f2f"').findall(
        veri)
    for link, name in match:
        liste(name, baseurl + link, 2, simge)
    if match2:
        sayi = re.sub(r"\?page=(.+?)&type=Standart", r'\1', match2[0])
        liste("Sonraki Sayfa (" + sayi + ")", baglanti + match2[0], 1, "")
    liste("ANA MENÜYE DÖN", "", "", simge)

def BOLUMLER(url):
    veri = getir(url)
    baglanti = url
    baglanti = re.sub(r"\?.+", "", baglanti)
    match = re.compile('<div class=".+? item">\n<a href="(.+?)" title="(.+?)">\n<div class="image">\n<img src="(.+?)" alt=".+?" />').findall(veri)
    match2 = re.compile(
        '<li class="next pager_element page-item">\n<a href="(.+?)" title="Sonraki" class="page-link".+?background-color:#2f2f2f"').findall(
        veri)
    for url, name, thumbnail in match:
        liste(name, baseurl + url, 4, thumbnail)
    if match2:
        sayi = re.sub(r"\?page=(.+?)", r'\1', match2[0])
        liste("Sonraki Sayfa (" + sayi + ")", baglanti + match2[0], 2, "")
'''
        for sonraki in match2:
            sayi = re.sub(r"\?page=(.+?)", r'\1', sonraki)
            liste("Sonraki Sayfa (" + sayi + ")", baglanti + sonraki, 2, "")
'''


def BOLUMDEN(url):
    veri = getir(url)
    match = re.compile('url: "(.+?)",').findall(veri)
    match2 = re.compile('<div class="ozetWrapper">\n(.+)').findall(veri)
    match3 = re.compile('<meta name="thumbnail" content="(.+?)"/>').findall(veri)
    match4 = re.compile('<a href="/ara/zaman/\d+?" class="filter-url">(\d+?)</a>').findall(veri)
    benzer = re.compile(
        '<div class="item col-lg-12 col-md-12 col-sm-4 col-xs-6">\n<a href="(.+?)" class="video_item_on_player" title="(.+?)">\n<div class="image">\n<img src="(.+?)" alt=').findall(
        veri)
    devami = re.compile('<div class="continue-watching">\n<a href="(.+?)\?t=.+?".+?">Devamını izle</a>').findall(veri)

    if not match3:
        match3 = " "

    if not match4:
        match4 = " "

    for url, desc, resim, tarih in zip(match, match2, match3, match4):
        goruntu("[COLOR green]►[/COLOR] " + name, url, resim, desc, tarih)

    if devami:
        for url in devami:
            liste("[COLOR yellow]Videonun Yer Aldığı Programın Tamamı[/COLOR]", baseurl + url, 7, simge)

    if benzer:
        liste("[COLOR lightgreen] - Bu Videoya Benzer Videolar - [/COLOR]", "/", 2, simge)
        for url, isim, resim in benzer:
            liste(isim, baseurl + url, 4, resim)
        liste("ANA MENÜYE DÖN", "", "", simge)

def TAMAMI(url):
    veri = getir(url)
    match = re.compile('url: "(.+?)",').findall(veri)
    match1 = re.compile('<title>(.+?)</title>').findall(veri)
    match2 = re.compile('<div class="ozetWrapper">\n(.+)').findall(veri)
    match3 = re.compile('<meta name="thumbnail" content="(.+?)"/>').findall(veri)
    match4 = re.compile('<a href="/ara/zaman/\d+?" class="filter-url">(\d+?)</a>').findall(veri)

    if not match3:
        match3 = " "

    if not match4:
        match4 = " "

    for url,name,desc,resim,tarih in zip(match,match1,match2,match3,match4):
        goruntu("[COLOR green]►[/COLOR] " + name, url, resim, desc, tarih)

def ARAMA(url):
    aramaterimi = ""
    if "?bul" in url:
        keyboard = xbmc.Keyboard('', "Arama", False)
        keyboard.doModal()
        if (keyboard.isConfirmed()):
            aramaterimi = keyboard.getText()
            querystring = str(urllib.quote(aramaterimi))
            url = url + querystring

            veri = getir(url)
            match = re.compile(
                '<a href="(.+?)" class="video_item" title="(.+?)">\n<div class="image">\n<img src=(.+?) alt').findall(
                veri)
            for url, name, thumbnail in match:
                liste(name, baseurl + url, 4, thumbnail)

def SONVIDEOLAR(url):
    veri = getir(url)
    match = re.compile(
        '<div class="swiper-container swiper-container-lastAdded">(.+?)<div class="swiper-button-next"></div>',
        re.S).findall(veri)
    for match in match:
        match2 = re.compile(
            '<a href="(.+?)" class="video_item" title="(.+?)">\n<div class="image">\n<img src="(.+?)" alt').findall(
            match)
        for url, name, thumbnail in match2:
            liste(name, baseurl + url, 4, thumbnail)

def COKBAKILANLAR(url):
    veri = getir(url)
    match = re.compile(
        '<div class="swiper-container swiper-container-mostViewed">(.+?)<div class="swiper-button-next"></div>',
        re.S).findall(veri)
    for match in match:
        match2 = re.compile(
            '<a href="(.+?)" class="video_item" title="(.+?)">\n<div class="image">\n<img src="(.+?)" alt').findall(
            match)
        for url, name, thumbnail in match2:
            liste(name, baseurl + url, 4, thumbnail)

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


def showMessage(heading='Hata', message='', times=3000, pics=''):
    try:
        xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, pics))
    except Exception, e:
        xbmc.log('[%s]: showMessage: exec failed [%s]' % ('', e), 1)

def goruntu(name, url, iconimage, aciklama, tarih):
    ok = True
    list_item = xbmcgui.ListItem(label=name)
    list_item.setInfo(type='Video', infoLabels={'title': name, 'plot': aciklama, 'year': tarih, 'thumb': iconimage})
    list_item.setArt(
        {'thumb': iconimage, 'icon': iconimage, 'fanart': iconimage, 'banner': iconimage, 'poster': iconimage})
    list_item.setProperty('IsPlayable', 'true')
    is_folder = False
    xbmcplugin.setContent(_handle, 'videos')
    xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    return ok

def liste(name,url, mode, iconimage):
    url = _url + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    ok = True
    list_item = xbmcgui.ListItem(label=name)
    list_item.setArt({'thumb': iconimage, 'icon': iconimage, 'fanart': background})
    list_item.setInfo(type='Video', infoLabels={'title': name})
    is_folder = True
    xbmcplugin.setContent(_handle, 'videos')
    xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    return ok

params = get_params()
url = None
name = None
mode = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)

if mode == None or url == None or len(url) < 1:
    print ""
    ANA()
elif mode == 1:
    print "" + url
    KATEGORI(url)
elif mode == 2:
    print "" + url
    BOLUMLER(url)
elif mode == 4:
    print "" + url
    BOLUMDEN(url)
elif mode == 5:
    print "" + url
    SONVIDEOLAR(url)
elif mode == 6:
    print "" + url
    COKBAKILANLAR(url)
elif mode == 7:
    print "" + url
    TAMAMI(url)
elif mode == 8:
    print "" + url
    ARAMA(url)

xbmcplugin.endOfDirectory(_handle)
