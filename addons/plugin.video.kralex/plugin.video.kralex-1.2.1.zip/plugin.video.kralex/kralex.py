import sys, platform
import urlresolver
import urllib, urllib2, cookielib
import re, xbmcplugin, xbmcgui, xbmcaddon, xbmc
import json
from urlparse import parse_qsl
from urllib import urlencode

reload(sys)
sys.setdefaultencoding('utf-8')
xbmcPlayer = xbmc.Player()
settings = xbmcaddon.Addon(id='plugin.video.kralex')
_url = sys.argv[0]
_handle = int(sys.argv[1])

getir = "http://kralex.tk/script/index.php?ana"

def Kaynak():
    kralex(getir)

def kralex(url):
    aramaterimi = ""
    if "?bul" in url:
        keyboard = xbmc.Keyboard('', "Arama", False)
        keyboard.doModal()
        if (keyboard.isConfirmed()):
            aramaterimi = keyboard.getText()
            url = url + aramaterimi
        else:return

    req = urllib2.Request(url)
    req.add_header('User-Agent', str(platform.uname()))
    f = urllib2.urlopen(req)
    cikti = json.load(f)

    for rs in cikti['Veri']:
        baslik = rs['Baslik'].encode('utf-8')
        baslik = baslik.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&#038;", "&").replace("&#39;", "'").replace("&#039;", "'").replace("&#8211;", "-").replace("&#8220;", "-").replace("&#8221;", "-").replace("&#8217;", "'").replace("&quot;", "\"")
        resim = rs['Resim']
        if 'Liste' in rs:
            liste = rs['Liste']
        else:
            liste = None
        if 'Goruntu' in rs:
            goruntu = rs['Goruntu']
        else:
            goruntu = None
        if 'Aciklama' in rs:
            aciklama = rs['Aciklama']
        else:
            aciklama = None
        if 'Tarih' in rs:
            tarih = rs['Tarih']
        else:
            tarih = None
        if 'Fanart' in rs:
            fanart = rs['Fanart']
        else:
            fanart = resim
        if 'Sure' in rs:
            sure = rs['Sure']
            #sure = YTSureSaniye(vakit)
        else:
            sure = None
        #if aciklama is None:
        #    aciklama = "Hi"+u"\u00E7" + "bir bilgi yok."

        if liste:
            url = str(liste)
            url = get_url(action='listing', category=url)
            list_item = xbmcgui.ListItem(label=baslik)
            list_item.setArt({'thumb': resim, 'icon': resim, 'fanart': fanart})
            list_item.setInfo(type='Video', infoLabels={'title': baslik, 'plot': aciklama, 'premiered': tarih})
            is_folder = True
            xbmcplugin.setContent(_handle, 'videos')
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

        if goruntu:
            url = str(goruntu)
            url = get_url(action='play', video=url)
            list_item = xbmcgui.ListItem(label=baslik)
            list_item.setInfo(type='Video', infoLabels =  {'title': baslik, 'plot': aciklama, 'premiered': tarih, 'thumb': resim, 'duration': sure})
            list_item.setArt({'thumb': resim, 'icon': resim, 'fanart': fanart, 'banner': resim, 'poster': resim})
            list_item.setProperty('IsPlayable', 'true')
            is_folder = False
            xbmcplugin.setContent(_handle, 'videos')
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

    xbmcplugin.endOfDirectory(_handle)

def oynat(url):
    url = str(url).encode('utf-8', 'ignore')
    if '.ts' in url:
        url = url
    elif 'rtmp:' in url:
        url = url
    elif 'rtsp:' in url:
        url = url
    elif '.ts:' in url:
        url = url
    elif '.m3u8' in url:
        url = url
    elif '.flv' in url:
        url = url
    elif '0p' in url:
        url = url
    elif '.mp4' in url:
        url = url
    elif '.mp3' in url:
        url = url
    elif '.wma' in url:
        url = url
    else:
        url = urlresolver.resolve(url)
    if url:
        play_item = xbmcgui.ListItem(path=url)
        xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    else:
        showMessage("[COLOR red][B]Hata[/B][/COLOR]", "[COLOR blue][B]Link bulunamadi ya da acilamiyor[/B][/COLOR]")

def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))

def showMessage(heading='Not', message='', times=3000, pics=''):
    try:
        xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, pics))
    except Exception, e:
        xbmc.log('[%s]: showMessage: exec failed [%s]' % ('', e), 1)

def router(paramstring):
    params = dict(parse_qsl(paramstring))

    if params:
        if params['action'] == 'listing':
            kralex(params['category'])
        elif params['action'] == 'play':
            oynat(params['video'])
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        Kaynak()
'''
def YTSureSaniye(duration):
  match = re.match('PT(\d+H)?(\d+M)?(\d+S)?', duration).groups()
  hours = _js_parseInt(match[0]) if match[0] else 0
  minutes = _js_parseInt(match[1]) if match[1] else 0
  seconds = _js_parseInt(match[2]) if match[2] else 0
  return hours * 3600 + minutes * 60 + seconds

def _js_parseInt(string):
    return int(''.join([x for x in string if x.isdigit()]))
'''

if __name__ == '__main__':
    router(sys.argv[2][1:])
