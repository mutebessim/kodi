﻿# -*- coding: utf-8 -*-
import xbmcgui, xbmcaddon, xbmc
import sys, time, datetime
import urllib2, re, threading
from resources.lib import altin, kuveytturk, garanti

ayarlar = xbmcaddon.Addon().getSetting
kur = ayarlar('kur')
coklu1 = ayarlar('coklu1')
coklu2 = ayarlar('coklu2')
coklu3 = ayarlar('coklu3')
coklu4 = ayarlar('coklu4')
yenileme = ayarlar('yenileme')
gorunum = ayarlar('gorunum')  # 0: Tekli, 1: Detaylı, 2-3-4-5: Çoklu
kaynak = ayarlar('kaynak')  # 0: altin.in
fiyat = ayarlar('fiyat')  # 0: alış, 1: satış
arkaplan = ayarlar('arkaplan')

dt = datetime.datetime

# useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'
# header = {'Referer': 'https://altin.in', 'User-Agent': useragent}

# url = 'https://getir.altin.in/guncel.asp'

ACTION_PREVIOUS_MENU = 9
ACTION_SELECT_ITEM = 7
ACTION_STEP_BACK = 21

W = 150
H = 80

X = int(ayarlar('konumX'))
Y = int(ayarlar('konumY'))

if arkaplan == 'Siyah':
    background = 'special://home/addons/script.kralex.foreign/image/b1.png'

elif arkaplan == 'Mavi':
    background = 'special://home/addons/script.kralex.foreign/image/b2.png'

elif arkaplan == 'Bordo':
    background = 'special://home/addons/script.kralex.foreign/image/b3.png'

elif arkaplan == 'Yesil':
    background = 'special://home/addons/script.kralex.foreign/image/b4.png'

elif arkaplan == 'Kahverengi':
    background = 'special://home/addons/script.kralex.foreign/image/b5.png'

elif arkaplan == 'Mor':
    background = 'special://home/addons/script.kralex.foreign/image/b6.png'

elif arkaplan == 'Turuncu':
    background = 'special://home/addons/script.kralex.foreign/image/b7.png'

image = xbmcgui.ControlImage(x=X, y=Y, width=W, height=H - 33, filename=background)
imageDetayli = xbmcgui.ControlImage(x=X, y=Y, width=W, height=H, filename=background)
kurLabel = xbmcgui.ControlLabel(x=X, y=Y - 8, width=W, height=H, font='font_clock', label='', alignment=2)
kurLabelOns = xbmcgui.ControlLabel(x=X, y=Y, width=W, height=H, font='font45', label='', alignment=2)

kurLabelUst = xbmcgui.ControlLabel(x=X, y=Y - 2, width=W, height=H, font='font12', label='', alignment=2)
kurLabelOrta = xbmcgui.ControlLabel(x=X, y=Y + 9, width=W, height=H, font='font_clock', label='', alignment=2)
kurLabelAlt = xbmcgui.ControlLabel(x=X, y=Y + 58, width=W, height=H, font='font12', label='', alignment=2)
kurLabelOrtaOns = xbmcgui.ControlLabel(x=X, y=Y + 17, width=W, height=H, font='font45', label='', alignment=2)

imageCoklu = xbmcgui.ControlImage(x=X - 2, y=Y, width=W + 5, height=H + 9, filename=background)
cokluSolLabel = xbmcgui.ControlLabel(x=X, y=Y - 1, width=W, height=H, font='font12', label='', alignment=0)
cokluSagLabel = xbmcgui.ControlLabel(x=X, y=Y - 1, width=W, height=H, font='font12', label='', alignment=1)


def kalin(metin):
    cikti = '[B]' + metin + '[/B]'
    return cikti


def kisalt(girdi):
    cikti = girdi.replace('Dolar', 'USD/TRY').replace('Euro', 'EUR/TRY').replace('Sterlin', 'STERLİN').replace('Gumus',
                                                                                                               'GÜMÜŞ').replace(
        'Parite', 'PARİTE').replace('Ons', 'ONS').replace('Gram', 'GRAM')
    return cikti


class kurThreadClass(threading.Thread):
    def run(self):
        self.shutdown = False
        while not self.shutdown:
            saat = '{:02d}:{:02d}:{:02d}'.format(dt.now().hour, dt.now().minute, dt.now().second)

            coklu1b = kisalt(coklu1)
            coklu2b = kisalt(coklu2)
            coklu3b = kisalt(coklu3)
            coklu4b = kisalt(coklu4)

            if kaynak == '0':  # altin.in
                Kurlar = altin.oranlar()

            elif kaynak == '1':  # kuveytturk
                Kurlar = kuveytturk.oranlar()

            elif kaynak == '2':  # kuveytturk
                Kurlar = garanti.oranlar()

            if fiyat == '0':
                Dolar = Kurlar['dolarA']
                Euro = Kurlar['euroA']
                Sterlin = Kurlar['sterlinA']
                Gumus = Kurlar['gumusA']
                Parite = Kurlar['pariteA']
                Ons = Kurlar['onsA']
                Gram = Kurlar['gramA']
                Ceyrek = Kurlar['ceyrekA']


            else:
                Dolar = Kurlar['dolarS']
                Euro = Kurlar['euroS']
                Sterlin = Kurlar['sterlinS']
                Gumus = Kurlar['gumusS']
                Parite = Kurlar['pariteS']
                Ons = Kurlar['onsS']
                Gram = Kurlar['gramS']
                Ceyrek = Kurlar['ceyrekS']

            if kur == 'Dolar':
                Baslik = 'DOLAR / TL{}'.format(Kurlar['dolarD'].encode('utf-8'))
                Kur = Dolar

            elif kur == 'Euro':
                Baslik = 'EURO / TL{}'.format(Kurlar['euroD'].encode('utf-8'))
                Kur = Euro

            elif kur == 'Sterlin':
                Baslik = 'STERLİN / TL{}'.format(Kurlar['sterlinD'].encode('utf-8'))
                Kur = Sterlin

            elif kur == 'Gumus':
                Baslik = 'GÜMÜŞ GRAM{}'.format(Kurlar['gumusD'].encode('utf-8'))
                Kur = Gumus

            elif kur == 'Parite':
                Baslik = 'PARİTE{}'.format(Kurlar['pariteD'].encode('utf-8'))
                Kur = Parite

            elif kur == 'Ons':
                Baslik = 'ALTIN ONS{}'.format(Kurlar['onsD'].encode('utf-8'))
                Kur = Ons

            elif kur == 'Gram':
                Baslik = 'ALTIN GRAM{}'.format(Kurlar['gramD'].encode('utf-8'))
                Kur = Gram

            elif kur == 'Ceyrek':
                Baslik = 'ÇEYREK ALTIN{}'.format(Kurlar['ceyrekD'].encode('utf-8'))
                Kur = Ceyrek

            if gorunum == '0' and kur != 'Ons':
                kurLabel.setLabel(kalin(Kur))

            if gorunum == '0' and kur == 'Ons':
                kurLabelOns.setLabel(Kur)

            if gorunum == '1' and kur != 'Ons':
                kurLabelOrta.setLabel(kalin(Kur))
                kurLabelUst.setLabel(Baslik)
                kurLabelAlt.setLabel(kalin(saat))

            if gorunum == '1' and kur == 'Ons':
                kurLabelOrtaOns.setLabel(Kur)
                kurLabelUst.setLabel(Baslik)
                kurLabelAlt.setLabel(kalin(saat))

            if gorunum == '2':
                cokluSolLabel.setLabel(coklu1b + '\n' + coklu2b + '\n' + coklu3b + '\n' + coklu4b)
                cokluSagLabel.setLabel(
                    kalin(eval(coklu1) + '\n' + eval(coklu2) + '\n' + eval(coklu3) + '\n' + eval(coklu4)))

            time.sleep(float(yenileme))


class kurDialog(xbmcgui.WindowDialog):
    def __init__(self):
        if gorunum == '0':
            self.addControl(image)
            self.addControl(kurLabel)

        if gorunum == '1':
            self.addControl(imageDetayli)
            self.addControl(kurLabelOrta)
            self.addControl(kurLabelUst)
            self.addControl(kurLabelAlt)

        if kur == 'Ons':
            self.addControl(kurLabelOns)
            self.addControl(kurLabelOrtaOns)

        if gorunum >= '2':
            self.addControl(imageCoklu)
            self.addControl(cokluSolLabel)
            self.addControl(cokluSagLabel)

        self.kurThread = kurThreadClass()
        self.kurThread.start()

    def onAction(self, action):
        if action == ACTION_SELECT_ITEM:
            self.close()


if __name__ == '__main__':
    xbmc.executebuiltin('ActivateWindow (home, return)')
    xbmc.sleep(200)
    xbmc.executebuiltin('xbmc.activatewindow(fullscreenvideo, return)')
    xbmc.sleep(300)
    dialog = kurDialog()
    dialog.doModal()
    del dialog
    xbmc.executebuiltin('Dialog.Close(10138)')
    sys.modules.clear()
