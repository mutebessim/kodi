# -*- coding: utf-8 -*-
import requests, re, logging

url= 'https://getir.altin.in/guncel.asp'

logging.basicConfig(level=logging.DEBUG)


def oranlar():
    veri = requests.get(url)
    veri = veri.text

    dolar = re.compile("dolar_guncelle\('(.*?)','.*?'\)").findall(veri)
    euro = re.compile("euro_guncelle\('(.*?)','.*?'\)").findall(veri)
    sterlin = re.compile("sterlin_guncelle\('(.*?)','.*?'\)").findall(veri)
    gumus = re.compile("gumus_guncelle\('(.*?)','(.*?)','.*?',.*?\)").findall(veri)
    parite = re.compile("parite_guncelle\('(.*?)','.*?'\)").findall(veri)
    ons = re.compile("ons_guncelle\('(.*?)','.*?'\)").findall(veri)
    gram = float(ons[0]) / 31.1034768 * float(dolar[0])
    gram1 = str(round(gram, 2))

    ceyrek = gram * 1.605 + 2.26
    ceyrek1 = str(round(ceyrek, 2))

    Kurlar ={
        'dolarA': dolar[0], 'dolarS': dolar[0], 'dolarD': '', 'dolarB': 'DOLAR / TL',
        'euroA': euro[0], 'euroS': euro[0], 'euroD': '', 'euroB': 'EURO / TL',
        'sterlinA': sterlin[0], 'sterlinS': sterlin[0], 'sterlinD': '', 'sterlinB': u'STERL\u0130N / TL',
        'gumusA': gumus[0][0], 'gumusS': gumus[0][1], 'gumusD': '', 'gumusB': u'G\u00DCM\u00DC\u015E GRAM',
        'pariteA': parite[0], 'pariteS': parite[0], 'pariteD': '', 'pariteB': u'PAR\u0130TE',
        'onsA': ons[0], 'onsS': ons[0], 'onsD': '', 'onsB': 'ONS ALTIN',
        'gramA': gram1, 'gramS': gram1, 'gramD': '', 'gramB': 'GRAM ALTIN',
        'ceyrekA': ceyrek1, 'ceyrekS': ceyrek1, 'ceyrekD': '', 'ceyrekB': u'\u00C7EYREK ALTIN'
    }
    return Kurlar
