# -*- coding: utf-8 -*-
import requests
import xml.etree.ElementTree as ET

url = 'https://www.garanti.com.tr/proxy/asp/xml/icpiyasaX.xml'
garanti = 'https://www.garanti.com.tr'

header = {'Referer': garanti,
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'}


def oranlar():
    veri = requests.get(headers=header, url=url)
    veri = veri.text
    veri = veri.replace(',', '.')

    tree = ET.fromstring(veri)

    for symbol, desc, last, pernc, pern_num, last_mod in tree:
        print symbol.text
        if symbol.text == 'KEUR':
            euro = last.text
        if symbol.text == 'KUSD':
            dolar = last.text
        if symbol.text == 'EUR':
            parite = last.text
        if symbol.text == 'KBP':
            sterlin = last.text
        if symbol.text == 'KGC':
            altin = last.text


    Kurlar ={
        'dolarA': dolar, 'dolarS': dolar, 'dolarD': '',
        'euroA': euro, 'euroS': euro, 'euroD': '',
        'sterlinA': sterlin, 'sterlinS': sterlin, 'sterlinD': '',
        'gumusA': 'N/A', 'gumusS': 'N/A', 'gumusD': '',
        'pariteA': parite, 'pariteS': parite, 'pariteD': '',
        'onsA': 'N/A', 'onsS': 'N/A', 'onsD': '',
        'gramA': altin, 'gramS': altin, 'gramD': '',
        'ceyrekA': 'N/A', 'ceyrekS': 'N/A', 'ceyrekD': ''
    }
    return Kurlar