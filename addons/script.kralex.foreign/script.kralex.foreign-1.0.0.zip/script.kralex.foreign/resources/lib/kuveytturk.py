# -*- coding: utf-8 -*-
import requests, re, logging


url = 'https://www.kuveytturk.com.tr/apps/kurlar'
hangisi = 'alis'

logging.basicConfig(level=logging.DEBUG)

def oranlar():
    veri = requests.get(url)
    veri = veri.text
    veri = veri.replace('_State">1</span>', u'_State">\u25B2</span>').replace('_State">-1</span>', u'_State">\u25BC</span>')
    dolarA = re.compile('<span id="lblUSD_Buy">(.*?)</span>').findall(veri)
    dolarD = re.compile('<span id="lblUSD_Buy_State">(.*?)</span>').findall(veri)
    dolarS = re.compile('<span id="lblUSD_Sell">(.*?)</span>').findall(veri)

    euroA = re.compile('<span id="lblEURO_Buy">(.*?)</span>').findall(veri)
    euroD = re.compile('<span id="lblEURO_Buy_State">(.*?)</span>').findall(veri)
    euroS = re.compile('<span id="lblEURO_Sell">(.*?)</span>').findall(veri)

    pariteA = re.compile('<span id="lblParite_Buy">(.*?)</span>').findall(veri)
    pariteD = re.compile('<span id="lblParite_Buy_State">(.*?)</span>').findall(veri)
    pariteS = re.compile('<span id="lblParite_Sell">(.*?)</span>').findall(veri)

    gramA = re.compile('<span id="GoldBuyLabel">(.*?)</span>').findall(veri)
    gramD = re.compile('<span id="GoldBuyLabel_State">(.*?)</span>').findall(veri)
    gramS = re.compile('<span id="GoldSellLabel">(.*?)</span>').findall(veri)

    onsA = re.compile('<span id="lblGoldOunce">(.*?)</span>').findall(veri)
    onsD = re.compile('<span id="lblGoldOunce_State">(.*?)</span>').findall(veri)

    gumusA = re.compile('<span id="SilverBuyLabel">(.*?)</span>').findall(veri)
    gumusD = re.compile('<span id="SilverBuyLabel_State">(.*?)</span>').findall(veri)
    gumusS = re.compile('<span id="SilverSellLabel">(.*?)</span>').findall(veri)

    ceyrekA = re.compile('<span id="ZCeyrekBuyLabel">(.*?)</span>').findall(veri)
    ceyrekD = re.compile('<span id="ZCeyrekBuyLabel_State">(.*?)</span>').findall(veri)
    ceyrekS = re.compile('<span id="ZCeyrekSellLabel">(.*?)</span>').findall(veri)


    gramA = float(gramA[0])
    gramA = str(round(gramA, 2))

    gramS = float(gramS[0])
    gramS = str(round(gramS, 2))

    ceyrekA = float(ceyrekA[0])
    ceyrekA = str(round(ceyrekA, 2))

    ceyrekS = float(ceyrekS[0])
    ceyrekS = str(round(ceyrekS, 2))

    Kurlar = {
        'dolarA': dolarA[0], 'dolarS': dolarS[0], 'dolarD': dolarD[0],
        'euroA': euroA[0], 'euroS': euroS[0], 'euroD': euroD[0],
        'sterlinA': '', 'sterlinS': '', 'sterlinD': '',
        'gumusA': gumusA[0], 'gumusS': gumusS[0], 'gumusD': gumusD[0],
        'pariteA': pariteA[0], 'pariteS': pariteS[0], 'pariteD': pariteD[0],
        'onsA': onsA[0], 'onsS': onsA[0], 'onsD': onsD[0],
        'gramA': gramA, 'gramS': gramS, 'gramD': gramD[0],
        'ceyrekA': ceyrekA, 'ceyrekS': ceyrekS, 'ceyrekD': ceyrekD[0]
    }

    return Kurlar
